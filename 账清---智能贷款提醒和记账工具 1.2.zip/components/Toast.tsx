import React, { useState, useEffect } from 'react';
import { CloseIcon } from './icons/CloseIcon';

interface ToastProps {
  message: string;
  type: 'success' | 'error';
  onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({ message, type, onClose }) => {
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      handleClose();
    }, 2800);

    return () => clearTimeout(timer);
  }, []);

  const handleClose = () => {
    setExiting(true);
    setTimeout(onClose, 300); // Wait for exit animation
  };

  const bgColor = type === 'success' 
    ? 'bg-green-100 border-green-400 text-green-700 dark:bg-green-800/80 dark:border-green-600 dark:text-green-200'
    : 'bg-red-100 border-red-400 text-red-700 dark:bg-red-800/80 dark:border-red-600 dark:text-red-200';

  const animationClass = exiting ? 'animate-toast-exit' : 'animate-toast-enter';

  return (
    <div
      className={`p-4 mb-4 text-sm rounded-lg border shadow-lg backdrop-blur-sm flex justify-between items-center ${bgColor} ${animationClass}`}
      role="alert"
    >
      <span className="font-medium">{message}</span>
      <button onClick={handleClose} className="ml-4 -mr-2 p-1 rounded-md hover:bg-white/50">
        <CloseIcon className="w-4 h-4" />
      </button>
       <style>{`
        @keyframes toast-enter {
          from { opacity: 0; transform: translateX(100%); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes toast-exit {
          from { opacity: 1; transform: translateX(0); }
          to { opacity: 0; transform: translateX(100%); }
        }
        .animate-toast-enter { animation: toast-enter 0.3s ease-out forwards; }
        .animate-toast-exit { animation: toast-exit 0.3s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default Toast;
