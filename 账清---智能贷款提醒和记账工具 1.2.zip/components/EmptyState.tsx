import React from 'react';
import { DocumentIcon } from './icons/DocumentIcon';

interface EmptyStateProps {
  title: string;
  message: string;
  icon?: React.ReactNode;
}

const EmptyState: React.FC<EmptyStateProps> = ({ title, message, icon }) => {
  return (
    <div className="text-center py-10 px-4">
      <div className="mx-auto h-12 w-12 text-slate-400 dark:text-slate-500">
        {icon || <DocumentIcon />}
      </div>
      <h3 className="mt-2 text-lg font-semibold text-slate-800 dark:text-slate-200">{title}</h3>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{message}</p>
    </div>
  );
};

export default EmptyState;
