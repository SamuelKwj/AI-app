import React, { useState, useRef, ChangeEvent, useEffect } from 'react';
import { Loan } from '../types';
import { extractLoanInfoFromImage } from '../services/geminiService';
import { CameraIcon } from './icons/CameraIcon';

interface AddLoanModalProps {
  onClose: () => void;
  onAddLoan: (loan: Omit<Loan, 'id' | 'remainingAmount'>) => void;
  onUpdateLoan?: (loan: Loan) => void;
  loanToEdit?: Loan;
}

const AddLoanModal: React.FC<AddLoanModalProps> = ({ onClose, onAddLoan, onUpdateLoan, loanToEdit }) => {
  const [loan, setLoan] = useState({
    lender: '',
    amount: '',
    interestRate: '',
    loanDate: new Date().toISOString().split('T')[0],
    repaymentDay: '',
    termInMonths: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [aiSuccessMessage, setAiSuccessMessage] = useState('');
  const [aiFilledFields, setAiFilledFields] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (loanToEdit) {
      setLoan({
        lender: loanToEdit.lender,
        amount: loanToEdit.amount.toString(),
        interestRate: loanToEdit.interestRate.toString(),
        loanDate: loanToEdit.loanDate,
        repaymentDay: loanToEdit.repaymentDay.toString(),
        termInMonths: loanToEdit.termInMonths?.toString() || '',
      });
    }
  }, [loanToEdit]);

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setLoan(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    setError('');
    setAiSuccessMessage('');
    setAiFilledFields([]);
    
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = (reader.result as string).split(',')[1];
        try {
          const extractedData = await extractLoanInfoFromImage(base64String);
          if (extractedData) {
            const filledFields: string[] = [];
            const updatedLoanState = { ...loan };

            Object.keys(extractedData).forEach(key => {
              const value = extractedData[key as keyof typeof extractedData];
              if (value) {
                updatedLoanState[key as keyof typeof updatedLoanState] = String(value);
                filledFields.push(key);
              }
            });

            setLoan(updatedLoanState);
            setAiFilledFields(filledFields);
            setAiSuccessMessage('信息已自动填充，请核对。');
            setTimeout(() => setAiFilledFields([]), 5000);

          } else {
            setError('未能从图片中识别有效信息。');
          }
        } catch (apiError: any) {
          setError(apiError.message || 'AI识图失败，请手动填写。');
        } finally {
          setIsLoading(false);
        }
      };
      reader.readAsDataURL(file);
    } catch (err) {
      setError('读取文件失败。');
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loan.lender || !loan.amount || !loan.repaymentDay) {
      setError('请填写所有必填项。');
      return;
    }

    const loanData = {
      lender: loan.lender,
      amount: parseFloat(loan.amount),
      interestRate: parseFloat(loan.interestRate) || 0,
      loanDate: loan.loanDate,
      repaymentDay: parseInt(loan.repaymentDay),
      termInMonths: loan.termInMonths ? parseInt(loan.termInMonths) : undefined,
    };

    if (loanToEdit && onUpdateLoan) {
      onUpdateLoan({
        ...loanToEdit,
        ...loanData
      });
    } else {
      onAddLoan(loanData);
    }
    onClose();
  };
  
  const today = new Date().toISOString().split('T')[0];
  const isEditing = !!loanToEdit;
  
  const inputClass = (fieldName: string) => {
    const baseClass = "mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500";
    const highlightClass = " border-cyan-500 ring-2 ring-cyan-300 transition-all duration-500";
    return baseClass + (aiFilledFields.includes(fieldName) ? highlightClass : '');
  };

  return (
    <div className="fixed inset-0 bg-black/60 dark:bg-black/80 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-md animate-slide-up" onClick={e => e.stopPropagation()}>
        <div className="p-6 border-b dark:border-slate-700">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200">{isEditing ? '编辑贷款' : '新增贷款'}</h2>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          {error && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">{error}</div>}
          
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-cyan-500 text-white font-semibold rounded-lg hover:bg-cyan-600 transition-colors disabled:bg-cyan-300 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                智能识别中...
              </>
            ) : (
              <>
                <CameraIcon className="w-5 h-5" />
                AI 识图录入
              </>
            )}
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
            accept="image/*"
          />
          {aiSuccessMessage && <p className="text-center text-sm text-green-600 dark:text-green-400 -mt-2">{aiSuccessMessage}</p>}

          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t dark:border-slate-600"></span>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white dark:bg-slate-800 px-2 text-gray-500 dark:text-gray-400">或手动填写</span>
            </div>
          </div>

          <div>
            <label htmlFor="lender" className="block text-sm font-medium text-gray-700 dark:text-gray-300">贷款平台/对象</label>
            <input type="text" name="lender" id="lender" value={loan.lender} onChange={handleChange} className={inputClass('lender')} placeholder="例如：花呗" required/>
          </div>
          <div>
            <label htmlFor="amount" className="block text-sm font-medium text-gray-700 dark:text-gray-300">总金额 (元)</label>
            <input type="number" name="amount" id="amount" value={loan.amount} onChange={handleChange} className={inputClass('amount')} placeholder="例如：5000" required/>
          </div>
          <div>
            <label htmlFor="interestRate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">年化利率 (%)</label>
            <input type="number" step="0.01" name="interestRate" id="interestRate" value={loan.interestRate} onChange={handleChange} className={inputClass('interestRate')} placeholder="例如：7.5 (选填)"/>
          </div>
          <div>
            <label htmlFor="loanDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">借款日期</label>
            <input type="date" name="loanDate" id="loanDate" value={loan.loanDate} onChange={handleChange} max={today} className={inputClass('loanDate')} required/>
          </div>
          <div>
            <label htmlFor="repaymentDay" className="block text-sm font-medium text-gray-700 dark:text-gray-300">每月还款日 (日)</label>
            <input type="number" name="repaymentDay" id="repaymentDay" value={loan.repaymentDay} onChange={handleChange} min="1" max="31" className={inputClass('repaymentDay')} placeholder="例如：15" required/>
          </div>
          <div>
            <label htmlFor="termInMonths" className="block text-sm font-medium text-gray-700 dark:text-gray-300">贷款期限 (月)</label>
            <input type="number" name="termInMonths" id="termInMonths" value={loan.termInMonths} onChange={handleChange} min="1" className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500" placeholder="例如：12 (选填)"/>
          </div>
          <div className="pt-4 flex justify-end gap-3">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 dark:bg-slate-600 dark:text-gray-200 dark:hover:bg-slate-500">取消</button>
            <button type="submit" className="px-6 py-2 bg-cyan-500 text-white font-semibold rounded-lg hover:bg-cyan-600">{isEditing ? '更新' : '保存'}</button>
          </div>
        </form>
      </div>
       <style>{`
        @keyframes slide-up {
          from { transform: translateY(20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        .animate-slide-up { animation: slide-up 0.3s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default AddLoanModal;