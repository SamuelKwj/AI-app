import React from 'react';
import { HomeIcon } from './icons/HomeIcon';
import { HistoryIcon } from './icons/HistoryIcon';
import { ExpensesIcon } from './icons/ExpensesIcon';
import { UserIcon } from './icons/UserIcon';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const NavItem: React.FC<{
  label: string;
  icon: React.ReactNode;
  isActive: boolean;
  onClick: () => void;
}> = ({ label, icon, isActive, onClick }) => {
  const activeClasses = 'text-cyan-500 dark:text-cyan-400';
  const inactiveClasses = 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200';

  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center justify-center w-full pt-2 pb-1 transition-colors duration-200 ${isActive ? activeClasses : inactiveClasses}`}
    >
      {icon}
      <span className="text-xs mt-1">{label}</span>
    </button>
  );
};

const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  return (
    <div className="h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md shadow-[0_-2px_10px_rgba(0,0,0,0.05)] dark:shadow-[0_-2px_10px_rgba(0,0,0,0.2)] flex justify-around items-center">
      <NavItem
        label="首页"
        icon={<HomeIcon className="w-6 h-6" />}
        isActive={activeTab === 'home'}
        onClick={() => setActiveTab('home')}
      />
      <NavItem
        label="记账"
        icon={<ExpensesIcon className="w-6 h-6" />}
        isActive={activeTab === 'expenses'}
        onClick={() => setActiveTab('expenses')}
      />
      <div className="w-16 h-16"></div> {/* Placeholder for the center button */}
      <NavItem
        label="历史"
        icon={<HistoryIcon className="w-6 h-6" />}
        isActive={activeTab === 'history'}
        onClick={() => setActiveTab('history')}
      />
      <NavItem
        label="我的"
        icon={<UserIcon className="w-6 h-6" />}
        isActive={activeTab === 'profile'}
        onClick={() => setActiveTab('profile')}
      />
    </div>
  );
};

export default BottomNav;