import React, { useState, useRef, ChangeEvent, useMemo } from 'react';
import { Loan, Payment } from '../types';
import { UploadIcon } from './icons/UploadIcon';
import Modal from './Modal';
import { formatCurrency } from '../utils/formatters';

const calculateMonthlyPayment = (principal: number, annualRate: number, termMonths: number): number | null => {
    if (principal <= 0 || annualRate < 0 || termMonths <= 0) return null;
    if (annualRate === 0) return principal / termMonths;

    const monthlyRate = annualRate / 100 / 12;
    const payment = (principal * monthlyRate * Math.pow(1 + monthlyRate, termMonths)) / (Math.pow(1 + monthlyRate, termMonths) - 1);
    return payment;
};

interface LogPaymentModalProps {
  loan: Loan;
  onClose: () => void;
  onAddPayment: (payment: Omit<Payment, 'id'>) => void;
}

const LogPaymentModal: React.FC<LogPaymentModalProps> = ({ loan, onClose, onAddPayment }) => {
  const [amount, setAmount] = useState(loan.remainingAmount.toString());
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [proofImage, setProofImage] = useState<string | undefined>(undefined);
  const [fileName, setFileName] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const suggestedPayment = useMemo(() => {
    if (loan.termInMonths && loan.interestRate > 0) {
        return calculateMonthlyPayment(loan.amount, loan.interestRate, loan.termInMonths);
    }
    return null;
  }, [loan]);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      const reader = new FileReader();
      reader.onloadend = () => {
        setProofImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const paymentAmount = parseFloat(amount);
    if (isNaN(paymentAmount) || paymentAmount <= 0) return;
    
    onAddPayment({
      loanId: loan.id,
      amount: paymentAmount,
      date: date,
      proofImageUrl: proofImage,
    });
    onClose();
  };

  return (
    <Modal isOpen={true} onClose={onClose} title={`为“${loan.lender}”记一笔还款`}>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="amount" className="block text-sm font-medium text-slate-700 dark:text-slate-300">
            还款金额 (元)
          </label>
           {suggestedPayment && <span className="text-xs text-slate-500 dark:text-slate-400 float-right mt-1">建议还款: {formatCurrency(suggestedPayment)}</span>}
          <div className="mt-1">
            <input
              type="number"
              name="amount"
              id="amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full border border-slate-300 dark:border-slate-600 rounded-md shadow-sm px-3 py-2 bg-white dark:bg-slate-700 focus:ring-cyan-500 focus:border-cyan-500"
              placeholder={`剩余待还 ${loan.remainingAmount.toFixed(2)}`}
              required
            />
          </div>
        </div>
        <div>
          <label htmlFor="date" className="block text-sm font-medium text-slate-700 dark:text-slate-300">
            还款日期
          </label>
          <div className="mt-1">
            <input
              type="date"
              name="date"
              id="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full border border-slate-300 dark:border-slate-600 rounded-md shadow-sm px-3 py-2 bg-white dark:bg-slate-700 focus:ring-cyan-500 focus:border-cyan-500"
              required
            />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">上传还款凭证 (可选)</label>
          <div
            onClick={() => fileInputRef.current?.click()}
            className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-300 dark:border-slate-600 border-dashed rounded-md cursor-pointer hover:border-cyan-400 dark:hover:border-cyan-500"
          >
            <div className="space-y-1 text-center">
              <UploadIcon className="mx-auto h-12 w-12 text-slate-400 dark:text-slate-500" />
              <div className="flex text-sm text-slate-600 dark:text-slate-400">
                <p className="pl-1">点击上传文件</p>
                <input ref={fileInputRef} id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept="image/*"/>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-500">{fileName || 'PNG, JPG, GIF up to 10MB'}</p>
            </div>
          </div>
          {proofImage && <img src={proofImage} alt="还款凭证预览" className="mt-4 rounded-md max-h-40 mx-auto" />}
        </div>
        <div className="flex justify-end gap-4 pt-4">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-200 rounded-md hover:bg-slate-300 dark:bg-slate-600 dark:text-slate-200 dark:hover:bg-slate-500"
          >
            取消
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-sm font-medium text-white bg-cyan-500 rounded-md hover:bg-cyan-600"
          >
            确认还款
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default LogPaymentModal;