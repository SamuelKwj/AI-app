import React, { useState, useEffect } from 'react';
import { Expense } from '../types';
import Modal from './Modal';

interface AddExpenseModalProps {
  onClose: () => void;
  onSave: (expense: Omit<Expense, 'id'>, id?: string) => void;
  expenseToEdit?: Expense;
  categories: string[];
  setCategories: React.Dispatch<React.SetStateAction<string[]>>;
}

const AddExpenseModal: React.FC<AddExpenseModalProps> = ({ onClose, onSave, expenseToEdit, categories, setCategories }) => {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState(categories[0] || '其他');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  
  const [showNewCategoryInput, setShowNewCategoryInput] = useState(false);
  const [newCategory, setNewCategory] = useState('');

  const isEditing = !!expenseToEdit;

  useEffect(() => {
    if (isEditing) {
      setDescription(expenseToEdit.description);
      setAmount(expenseToEdit.amount.toString());
      setCategory(expenseToEdit.category);
      setDate(expenseToEdit.date);
    }
  }, [expenseToEdit, isEditing]);

  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    if (value === '__add__') {
        setShowNewCategoryInput(true);
    } else {
        setCategory(value);
        setShowNewCategoryInput(false);
    }
  };

  const handleAddNewCategory = (e: React.MouseEvent<HTMLButtonElement> | React.KeyboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const trimmedCategory = newCategory.trim();
    if (trimmedCategory && !categories.includes(trimmedCategory)) {
        setCategories(prev => [...prev, trimmedCategory]);
        setCategory(trimmedCategory);
        setShowNewCategoryInput(false);
        setNewCategory('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description || !amount) return;
    onSave({
      description,
      amount: parseFloat(amount),
      category,
      date,
    }, expenseToEdit?.id);
  };
  
  return (
    <Modal isOpen={true} onClose={onClose} title={isEditing ? '编辑消费' : '记一笔消费'}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">描述</label>
          <input
            type="text"
            value={description}
            onChange={e => setDescription(e.target.value)}
            className="mt-1 block w-full border border-slate-300 dark:border-slate-600 rounded-md shadow-sm px-3 py-2 bg-white dark:bg-slate-700 focus:ring-cyan-500 focus:border-cyan-500"
            required
            placeholder="例如：午餐"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">金额</label>
          <input
            type="number"
            value={amount}
            onChange={e => setAmount(e.target.value)}
            className="mt-1 block w-full border border-slate-300 dark:border-slate-600 rounded-md shadow-sm px-3 py-2 bg-white dark:bg-slate-700 focus:ring-cyan-500 focus:border-cyan-500"
            required
            placeholder="例如：25"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">分类</label>
          <select
            value={category}
            onChange={handleCategoryChange}
            className="mt-1 block w-full border border-slate-300 dark:border-slate-600 rounded-md shadow-sm px-3 py-2 bg-white dark:bg-slate-700 focus:ring-cyan-500 focus:border-cyan-500"
          >
            {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
            <option value="__add__">＋ 添加新分类</option>
          </select>
          {showNewCategoryInput && (
            <div className="mt-2 flex gap-2">
                 <input
                    type="text"
                    value={newCategory}
                    onChange={e => setNewCategory(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleAddNewCategory(e)}
                    placeholder="新分类名称"
                    className="flex-grow min-w-0 px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm text-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500"
                    autoFocus
                />
                <button type="button" onClick={handleAddNewCategory} className="px-4 py-2 bg-cyan-500 text-white text-sm font-semibold rounded-md hover:bg-cyan-600">添加</button>
            </div>
          )}
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">日期</label>
          <input
            type="date"
            value={date}
            onChange={e => setDate(e.target.value)}
            className="mt-1 block w-full border border-slate-300 dark:border-slate-600 rounded-md shadow-sm px-3 py-2 bg-white dark:bg-slate-700 focus:ring-cyan-500 focus:border-cyan-500"
            required
          />
        </div>
        <div className="flex justify-end gap-3 pt-4">
          <button type="button" onClick={onClose} className="px-4 py-2 bg-slate-200 dark:bg-slate-600 rounded-md">取消</button>
          <button type="submit" className="px-4 py-2 bg-cyan-500 text-white rounded-md">{isEditing ? '更新' : '保存'}</button>
        </div>
      </form>
    </Modal>
  );
};

export default AddExpenseModal;