import React, { useState, useCallback, useEffect } from 'react';
import HomePage from './pages/HomePage';
import HistoryPage from './pages/HistoryPage';
import ExpensesPage from './pages/ExpensesPage';
import ProfilePage from './pages/ProfilePage';
import BottomNav from './components/BottomNav';
import AddLoanModal from './components/AddLoanModal';
import AddExpenseModal from './components/AddExpenseModal';
import { PlusIcon } from './components/icons/PlusIcon';
import { useLocalStorage } from './hooks/useLocalStorage';
import { Loan, Payment, Expense } from './types';
import Toast from './components/Toast';
import { DEFAULT_EXPENSE_CATEGORIES } from './data/defaultData';

type ToastMessage = {
  id: number;
  message: string;
  type: 'success' | 'error';
};

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [isAddLoanModalOpen, setAddLoanModalOpen] = useState(false);
  const [isAddExpenseModalOpen, setAddExpenseModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | undefined>(undefined);

  const [loans, setLoans] = useLocalStorage<Loan[]>('loans', []);
  const [payments, setPayments] = useLocalStorage<Payment[]>('payments', []);
  const [expenses, setExpenses] = useLocalStorage<Expense[]>('expenses', []);
  const [expenseCategories, setExpenseCategories] = useLocalStorage<string[]>('expenseCategories', DEFAULT_EXPENSE_CATEGORIES);
  
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  
  const [theme, setTheme] = useLocalStorage<'light' | 'dark'>('theme', 'light');

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);
  
  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    const newToast: ToastMessage = { id: Date.now(), message, type };
    setToasts(prev => [...prev, newToast]);
    setTimeout(() => {
      setToasts(currentToasts => currentToasts.filter(t => t.id !== newToast.id));
    }, 3000);
  };

  useEffect(() => {
    if (!('Notification' in window)) {
      console.log("This browser does not support desktop notification");
    } else if (Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }, []);

  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'granted') {
      const activeLoans = loans.filter(l => l.remainingAmount > 0);

      activeLoans.forEach(loan => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const currentYear = today.getFullYear();
        const currentMonth = today.getMonth();

        const thisMonthDueDate = new Date(currentYear, currentMonth, loan.repaymentDay);
        
        if (today > thisMonthDueDate) {
          thisMonthDueDate.setMonth(thisMonthDueDate.getMonth() + 1);
        }

        const lastMonthDueDate = new Date(thisMonthDueDate);
        lastMonthDueDate.setMonth(lastMonthDueDate.getMonth() - 1);
        
        const hasPaidForCurrentCycle = payments.some(p => 
            p.loanId === loan.id && 
            new Date(p.date) > lastMonthDueDate &&
            new Date(p.date) <= thisMonthDueDate
        );

        if (hasPaidForCurrentCycle) return;

        const timeDiff = thisMonthDueDate.getTime() - today.getTime();
        const daysUntilDue = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
        
        let shouldNotify = false;
        let notificationBody = '';

        if (daysUntilDue <= 3 && daysUntilDue >= 0) {
          shouldNotify = true;
          notificationBody = `您的 “${loan.lender}” 贷款${daysUntilDue === 0 ? '今天到期' : `还有 ${daysUntilDue} 天到期`}，记得按时还款哦！`;
        } else if (today > thisMonthDueDate) { 
            const daysOverdue = Math.floor((today.getTime() - thisMonthDueDate.getTime()) / (1000 * 60 * 60 * 24));
             if(daysOverdue > 0){
                shouldNotify = true;
                notificationBody = `您的 “${loan.lender}” 贷款已逾期 ${daysOverdue} 天，请尽快处理！`;
            }
        }
        
        if (shouldNotify) {
            const title = '账清 - 还款提醒';
            new Notification(title, { body: notificationBody, tag: `loan-reminder-${loan.id}` });
        }
      });
    }
  }, [loans, payments, activeTab]);

  const addLoan = (loan: Omit<Loan, 'id' | 'remainingAmount'>) => {
    const newLoan: Loan = {
      ...loan,
      id: Date.now().toString(),
      remainingAmount: loan.amount,
    };
    setLoans(prev => [...prev, newLoan]);
    showToast('贷款添加成功');
  };
  
  const updateLoan = (updatedLoan: Loan) => {
    setLoans(prev => prev.map(l => l.id === updatedLoan.id ? updatedLoan : l));
    showToast('贷款信息更新成功');
  };

  const deleteLoan = (loanId: string) => {
    setLoans(prev => prev.filter(l => l.id !== loanId));
    setPayments(prev => prev.filter(p => p.loanId !== loanId));
    showToast('贷款已删除', 'success');
  };

  const addPayment = (payment: Omit<Payment, 'id'>) => {
    const newPayment: Payment = { ...payment, id: Date.now().toString() };
    setPayments(prev => [...prev, newPayment]);
    setLoans(prev => prev.map(loan => 
      loan.id === payment.loanId 
        ? { ...loan, remainingAmount: loan.remainingAmount - payment.amount }
        : loan
    ));
    showToast('还款记录成功');
  };
  
  const deletePayment = (paymentId: string) => {
    const paymentToDelete = payments.find(p => p.id === paymentId);
    if (!paymentToDelete) return;

    setLoans(prev => prev.map(loan =>
      loan.id === paymentToDelete.loanId
        ? { ...loan, remainingAmount: loan.remainingAmount + paymentToDelete.amount }
        : loan
    ));
    
    setPayments(prev => prev.filter(p => p.id !== paymentId));
    showToast('还款记录已删除');
  };
  
  const addExpense = (expense: Omit<Expense, 'id'>) => {
    const newExpense: Expense = { ...expense, id: Date.now().toString() };
    setExpenses(prev => [newExpense, ...prev]);
    showToast('消费记录添加成功');
  };

  const updateExpense = (updatedExpense: Expense) => {
    setExpenses(prev => prev.map(e => e.id === updatedExpense.id ? updatedExpense : e));
    showToast('消费记录更新成功');
  };
  
  const handleSaveExpense = (expenseData: Omit<Expense, 'id'>, id?: string) => {
    if (id) {
      updateExpense({ ...expenseData, id });
    } else {
      addExpense(expenseData);
    }
    setAddExpenseModalOpen(false);
  };

  const deleteExpense = (expenseId: string) => {
    setExpenses(prev => prev.filter(e => e.id !== expenseId));
    showToast('消费记录已删除');
  };

  const handleOpenAddExpenseModal = () => {
    setEditingExpense(undefined);
    setAddExpenseModalOpen(true);
  };

  const handleOpenEditExpenseModal = (expense: Expense) => {
    setEditingExpense(expense);
    setAddExpenseModalOpen(true);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <HomePage loans={loans} payments={payments} addPayment={addPayment} updateLoan={updateLoan} deleteLoan={deleteLoan} deletePayment={deletePayment} />;
      case 'history':
        return <HistoryPage loans={loans} payments={payments} deletePayment={deletePayment} />;
      case 'expenses':
        return <ExpensesPage expenses={expenses} openEditModal={handleOpenEditExpenseModal} deleteExpense={deleteExpense} />;
      case 'profile':
        return <ProfilePage 
                  theme={theme} 
                  setTheme={setTheme} 
                  loans={loans} 
                  payments={payments} 
                  expenses={expenses} 
                  setLoans={setLoans} 
                  setPayments={setPayments} 
                  setExpenses={setExpenses} 
                  showToast={showToast}
                  expenseCategories={expenseCategories}
                  setExpenseCategories={setExpenseCategories}
               />;
      default:
        return <HomePage loans={loans} payments={payments} addPayment={addPayment} updateLoan={updateLoan} deleteLoan={deleteLoan} deletePayment={deletePayment}/>;
    }
  };

  return (
    <div className="min-h-screen font-sans antialiased text-slate-800 bg-slate-50 dark:bg-slate-900 dark:text-slate-200 flex flex-col max-w-lg mx-auto shadow-2xl">
       <div id="toast-container" className="fixed top-5 right-5 z-[100] w-full max-w-xs">
        {toasts.map(toast => (
          <Toast key={toast.id} message={toast.message} type={toast.type} onClose={() => setToasts(ts => ts.filter(t => t.id !== toast.id))} />
        ))}
      </div>
      
      <main className="flex-1 pb-20 overflow-y-auto">
        {renderContent()}
      </main>

      <div className="fixed bottom-0 left-0 right-0 max-w-lg mx-auto z-40">
        <div className="relative">
          {activeTab === 'home' && (
            <button
              onClick={() => setAddLoanModalOpen(true)}
              className="absolute right-1/2 translate-x-1/2 -top-16 w-16 h-16 bg-cyan-500 rounded-full text-white shadow-lg flex items-center justify-center hover:bg-cyan-600 transition-all duration-300 transform hover:scale-110 focus:outline-none focus:ring-4 focus:ring-cyan-300"
              aria-label="新增贷款"
            >
              <PlusIcon className="w-8 h-8" />
            </button>
          )}
          {activeTab === 'expenses' && (
             <button
                onClick={handleOpenAddExpenseModal}
                className="absolute right-1/2 translate-x-1/2 -top-16 w-16 h-16 bg-amber-500 rounded-full text-white shadow-lg flex items-center justify-center hover:bg-amber-600 transition-all duration-300 transform hover:scale-110 focus:outline-none focus:ring-4 focus:ring-amber-300"
                aria-label="新增消费"
              >
                <PlusIcon className="w-8 h-8" />
              </button>
          )}
          <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
        </div>
      </div>
      
      {isAddLoanModalOpen && (
        <AddLoanModal 
          onClose={() => setAddLoanModalOpen(false)} 
          onAddLoan={addLoan}
        />
      )}
      {isAddExpenseModalOpen && (
        <AddExpenseModal 
            onClose={() => setAddExpenseModalOpen(false)}
            onSave={handleSaveExpense}
            expenseToEdit={editingExpense}
            categories={expenseCategories}
            setCategories={setExpenseCategories}
        />
      )}
    </div>
  );
};

export default App;