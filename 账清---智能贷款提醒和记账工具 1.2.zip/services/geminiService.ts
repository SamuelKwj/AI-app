
import { GoogleGenAI, Type } from "@google/genai";
import { Loan } from '../types';

if (!process.env.API_KEY) {
  // In a real app, you'd want to handle this more gracefully.
  // For this example, we'll alert the user and disable the feature.
  console.error("API_KEY environment variable not set. AI features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export const extractLoanInfoFromImage = async (base64Image: string): Promise<Partial<Omit<Loan, 'id' | 'remainingAmount'>> | null> => {
  if (!process.env.API_KEY) {
    throw new Error("Gemini API key is not configured.");
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: base64Image,
            },
          },
          {
            text: "请从这张图片中提取贷款信息。需要提取：贷款平台或对象(lender)、贷款总额-仅数字(amount)、年化利率-仅数字(interestRate)、借款日期-YYYY-MM-DD格式(loanDate)和每月还款日-仅数字1-31(repaymentDay)。如果某项信息缺失，请将其值留空或设为0。请务必以JSON格式返回。",
          },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            lender: {
              type: Type.STRING,
              description: "贷款平台或出借方名称",
            },
            amount: {
              type: Type.NUMBER,
              description: "贷款总金额",
            },
            interestRate: {
              type: Type.NUMBER,
              description: "年化利率",
            },
            loanDate: {
              type: Type.STRING,
              description: "借款日期，格式为 YYYY-MM-DD",
            },
            repaymentDay: {
              type: Type.INTEGER,
              description: "每月的还款日 (1-31)",
            },
          },
        },
      },
    });

    const jsonString = response.text.trim();
    if (jsonString) {
      return JSON.parse(jsonString) as Partial<Loan>;
    }
    return null;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("AI识图失败，请检查网络或稍后重试。");
  }
};
