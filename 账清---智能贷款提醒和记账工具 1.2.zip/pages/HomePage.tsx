import React, { useState, useMemo, useRef } from 'react';
import { Loan, Payment } from '../types';
import LogPaymentModal from '../components/LogPaymentModal';
import AddLoanModal from '../components/AddLoanModal';
import ConfirmationModal from '../components/ConfirmationModal';
import { DotsVerticalIcon } from '../components/icons/DotsVerticalIcon';
import { PencilIcon } from '../components/icons/PencilIcon';
import { TrashIcon } from '../components/icons/TrashIcon';
import { ArrowLeftIcon } from '../components/icons/ArrowLeftIcon';
import EmptyState from '../components/EmptyState';
import { formatCurrency } from '../utils/formatters';

interface HomePageProps {
  loans: Loan[];
  payments: Payment[];
  addPayment: (payment: Omit<Payment, 'id'>) => void;
  updateLoan: (loan: Loan) => void;
  deleteLoan: (loanId: string) => void;
  deletePayment: (paymentId: string) => void;
}

interface LoanStatus {
  date: Date;
  statusText: string;
  urgencyColor: string;
  daysForSort: number;
}

const getLoanStatus = (loan: Loan): LoanStatus => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const currentYear = today.getFullYear();
  const currentMonth = today.getMonth();

  const thisMonthDueDate = new Date(currentYear, currentMonth, loan.repaymentDay);
  
  if (today > thisMonthDueDate) {
    thisMonthDueDate.setMonth(thisMonthDueDate.getMonth() + 1);
  }

  const timeDiff = thisMonthDueDate.getTime() - today.getTime();
  const daysForSort = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
  
  let date: Date;
  let statusText: string;
  let urgencyColor: string;
  
  if (today.getTime() > thisMonthDueDate.getTime() && daysForSort < 0) {
      const lastMonthDueDate = new Date(thisMonthDueDate);
      lastMonthDueDate.setMonth(lastMonthDueDate.getMonth() - 1);
      const daysOverdue = Math.floor((today.getTime() - lastMonthDueDate.getTime()) / (1000 * 60 * 60 * 24)) - 30; // Approximation
      date = thisMonthDueDate;
      statusText = `逾期${daysOverdue}天`;
      urgencyColor = 'text-red-500 dark:text-red-400 font-bold animate-pulse';
  } else if (daysForSort >= 0) { 
    date = thisMonthDueDate;
    statusText = daysForSort === 0 ? '今天截止' : `${daysForSort}天后`;
    if (daysForSort <= 3) urgencyColor = 'text-red-500 dark:text-red-400 font-bold';
    else if (daysForSort <= 7) urgencyColor = 'text-amber-500 dark:text-amber-400 font-semibold';
    else urgencyColor = 'text-green-500 dark:text-green-400 font-medium';
  } else { 
     const daysOverdue = -daysForSort;
     date = thisMonthDueDate;
     statusText = `逾期${daysOverdue}天`;
     urgencyColor = 'text-red-500 dark:text-red-400 font-bold animate-pulse';
  }

  return { date, statusText, urgencyColor, daysForSort };
};

const LoanCard: React.FC<{ 
  loan: Loan; 
  status: LoanStatus; 
  onLogPayment: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onSelect: () => void;
}> = ({ loan, status, onLogPayment, onEdit, onDelete, onSelect }) => {
  const progress = (loan.amount - loan.remainingAmount) / loan.amount * 100;
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [menuRef]);

  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md dark:shadow-lg dark:shadow-black/20 mb-4 transition-all hover:shadow-lg dark:hover:bg-slate-700/50">
       <div className="p-5" onClick={onSelect} role="button" tabIndex={0}>
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-bold text-lg text-slate-800 dark:text-slate-200">{loan.lender}</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">总额: {loan.amount.toLocaleString('zh-CN')}元</p>
            </div>
            <div className="text-right flex-shrink-0">
              <p className={`${status.urgencyColor} text-lg`}>{status.statusText}</p>
              <p className="text-xs text-slate-400 dark:text-slate-500">
                {`${status.date.getMonth() + 1}月${status.date.getDate()}日`} 还款
              </p>
            </div>
          </div>
          <div className="mt-4">
            <div className="flex justify-between text-sm mb-1">
              <span className="text-slate-600 dark:text-slate-300">剩余</span>
              <span className="font-semibold text-cyan-600 dark:text-cyan-400">{loan.remainingAmount.toLocaleString('zh-CN')}元</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5">
              <div className="bg-cyan-500 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
          </div>
      </div>
      <div className="px-5 pb-4 flex justify-between items-center">
        <div className="relative" ref={menuRef}>
          <button onClick={() => setMenuOpen(!menuOpen)} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400">
            <DotsVerticalIcon className="w-5 h-5" />
          </button>
          {menuOpen && (
            <div className="absolute bottom-full left-0 mb-2 w-28 bg-white dark:bg-slate-700 rounded-md shadow-lg border dark:border-slate-600 z-10">
              <button onClick={() => { onEdit(); setMenuOpen(false); }} className="w-full text-left flex items-center gap-2 px-4 py-2 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600 rounded-t-md">
                <PencilIcon className="w-4 h-4" /> 编辑
              </button>
              <button onClick={() => { onDelete(); setMenuOpen(false); }} className="w-full text-left flex items-center gap-2 px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-b-md">
                <TrashIcon className="w-4 h-4" /> 删除
              </button>
            </div>
          )}
        </div>
         <button onClick={onLogPayment} className="bg-cyan-500 text-white px-5 py-2 rounded-lg text-sm font-semibold hover:bg-cyan-600 transition-colors">
          去还款
        </button>
      </div>
    </div>
  );
};

const LoanDetailView: React.FC<{
  loan: Loan;
  payments: Payment[];
  onBack: () => void;
  onDeletePayment: (paymentId: string) => void;
}> = ({ loan, payments, onBack, onDeletePayment }) => {
    const [deletingPayment, setDeletingPayment] = useState<Payment | null>(null);

    const handleDeleteConfirm = () => {
        if (deletingPayment) {
            onDeletePayment(deletingPayment.id);
            setDeletingPayment(null);
        }
    };
    
    return (
        <div className="p-4">
            <header className="flex items-center gap-4 mb-4">
                <button onClick={onBack} className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700">
                    <ArrowLeftIcon className="w-6 h-6" />
                </button>
                <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100">{loan.lender}</h1>
            </header>
            
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-sm p-4 space-y-2 mb-6 border border-slate-200 dark:border-slate-700">
                <div className="flex justify-between"><span className="text-slate-500">总金额</span><span>{formatCurrency(loan.amount)}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">剩余金额</span><span className="font-bold text-cyan-600 dark:text-cyan-400">{formatCurrency(loan.remainingAmount)}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">年利率</span><span>{loan.interestRate}%</span></div>
                <div className="flex justify-between"><span className="text-slate-500">借款日</span><span>{loan.loanDate}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">每月还款日</span><span>{loan.repaymentDay}日</span></div>
                {loan.termInMonths && <div className="flex justify-between"><span className="text-slate-500">期限</span><span>{loan.termInMonths}个月</span></div>}
            </div>

            <h2 className="text-lg font-semibold text-slate-700 dark:text-slate-300 mb-3">还款记录</h2>
            <div className="space-y-3">
                {payments.length > 0 ? [...payments].reverse().map(payment => (
                    <div key={payment.id} className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-sm border border-slate-200 dark:border-slate-700 group">
                        <div className="flex justify-between items-center">
                            <div className="flex-1 min-w-0">
                                <p className="font-semibold text-slate-800 dark:text-slate-200">- {formatCurrency(payment.amount)}</p>
                                <p className="text-sm text-slate-500 dark:text-slate-400">{payment.date}</p>
                            </div>
                            <div className="flex items-center gap-2 ml-4">
                               {payment.proofImageUrl && <a href={payment.proofImageUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-cyan-600 dark:text-cyan-400 hover:underline">凭证</a>}
                                <button onClick={() => setDeletingPayment(payment)} className="p-2 rounded-full text-slate-400 hover:bg-red-100 hover:text-red-600 dark:hover:bg-red-900/40 dark:hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <TrashIcon className="w-5 h-5" />
                                </button>
                            </div>
                        </div>
                    </div>
                )) : <EmptyState title="暂无记录" message="还没有这笔贷款的还款记录。" />}
            </div>

            {deletingPayment && (
                <ConfirmationModal
                    isOpen={!!deletingPayment}
                    onClose={() => setDeletingPayment(null)}
                    onConfirm={handleDeleteConfirm}
                    title="确认删除还款记录"
                    message={`您确定要删除这笔 ${deletingPayment.amount.toLocaleString()} 元的还款记录吗？贷款的剩余金额将会相应增加，此操作无法撤销。`}
                />
            )}
        </div>
    );
};


const HomePage: React.FC<HomePageProps> = ({ loans, payments, addPayment, updateLoan, deleteLoan, deletePayment }) => {
  const [logPaymentLoan, setLogPaymentLoan] = useState<Loan | null>(null);
  const [editingLoan, setEditingLoan] = useState<Loan | null>(null);
  const [deletingLoan, setDeletingLoan] = useState<Loan | null>(null);
  const [selectedLoan, setSelectedLoan] = useState<Loan | null>(null);

  const { totalDebt, sortedLoans } = useMemo(() => {
    const activeLoans = loans.filter(l => l.remainingAmount > 0);
    const totalDebt = activeLoans.reduce((sum, loan) => sum + loan.remainingAmount, 0);
    
    const sortedLoans = activeLoans
      .map(loan => ({ loan, status: getLoanStatus(loan) }))
      .sort((a, b) => a.status.daysForSort - b.status.daysForSort);
      
    return { totalDebt, sortedLoans };
  }, [loans]);

  const totalLoanAmount = useMemo(() => loans.reduce((sum, loan) => sum + loan.amount, 0), [loans]);

  const handleUpdateLoan = (updatedLoan: Loan) => {
    updateLoan(updatedLoan);
    setEditingLoan(null);
  };
  
  const handleDeleteConfirm = () => {
    if (deletingLoan) {
      deleteLoan(deletingLoan.id);
      setDeletingLoan(null);
    }
  };
  
  if (selectedLoan) {
    const loanPayments = payments.filter(p => p.loanId === selectedLoan.id);
    return <LoanDetailView loan={selectedLoan} payments={loanPayments} onBack={() => setSelectedLoan(null)} onDeletePayment={deletePayment} />;
  }

  return (
    <div className="p-4 bg-slate-50 dark:bg-slate-900 min-h-full">
      <header className="mb-6">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">早上好,</h1>
        <p className="text-slate-500 dark:text-slate-400">这是您的财务概览。</p>
      </header>
      
      <div className="bg-cyan-500 dark:bg-cyan-600 text-white p-6 rounded-2xl shadow-lg dark:shadow-cyan-900/50 mb-8">
        <p className="text-sm opacity-80 mb-1">剩余总债务</p>
        <p className="text-4xl font-bold tracking-tight">¥{totalDebt.toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
        <div className="mt-4 h-px bg-white/30"></div>
        <div className="flex justify-between mt-4 text-sm">
          <div>
            <p className="opacity-80">贷款总额</p>
            <p className="font-semibold">{totalLoanAmount.toLocaleString('zh-CN')}元</p>
          </div>
          <div>
            <p className="opacity-80">贷款笔数</p>
            <p className="font-semibold">{loans.filter(l => l.remainingAmount > 0).length} 笔</p>
          </div>
        </div>
      </div>
      
      {sortedLoans.length === 0 ? (
        <EmptyState 
            title="一身轻松！" 
            message="暂无待办贷款。点击下方 “+” 新增一笔贷款记录吧。"
        />
      ) : (
        <section>
          <h2 className="text-lg font-semibold text-slate-700 dark:text-slate-300 mb-3">待还贷款</h2>
          {sortedLoans.map(({ loan, status }) => (
            <LoanCard 
                key={loan.id} 
                loan={loan} 
                status={status} 
                onLogPayment={() => setLogPaymentLoan(loan)}
                onEdit={() => setEditingLoan(loan)}
                onDelete={() => setDeletingLoan(loan)}
                onSelect={() => setSelectedLoan(loan)}
            />
          ))}
        </section>
      )}

      {logPaymentLoan && (
        <LogPaymentModal 
          loan={logPaymentLoan}
          onClose={() => setLogPaymentLoan(null)}
          onAddPayment={addPayment}
        />
      )}

      {editingLoan && (
        <AddLoanModal
            loanToEdit={editingLoan}
            onClose={() => setEditingLoan(null)}
            onAddLoan={() => {}} // This won't be called in edit mode
            onUpdateLoan={handleUpdateLoan}
        />
      )}

      {deletingLoan && (
        <ConfirmationModal
            isOpen={!!deletingLoan}
            onClose={() => setDeletingLoan(null)}
            onConfirm={handleDeleteConfirm}
            title="确认删除贷款"
            message={`您确定要删除 “${deletingLoan.lender}” 这笔贷款吗？所有相关的还款记录也将被一并删除，此操作无法撤销。`}
        />
      )}
    </div>
  );
};

export default HomePage;