import React, { useState } from 'react';
import { Loan, Payment } from '../types';
import ConfirmationModal from '../components/ConfirmationModal';
import { TrashIcon } from '../components/icons/TrashIcon';
import EmptyState from '../components/EmptyState';

interface HistoryPageProps {
  loans: Loan[];
  payments: Payment[];
  deletePayment: (paymentId: string) => void;
}

const HistoryPage: React.FC<HistoryPageProps> = ({ loans, payments, deletePayment }) => {
  const [activeTab, setActiveTab] = useState('loans');
  const [deletingPayment, setDeletingPayment] = useState<Payment | null>(null);
  
  const paidOffLoans = loans.filter(l => l.remainingAmount <= 0);

  const getLenderName = (loanId: string) => {
    return loans.find(l => l.id === loanId)?.lender || '未知贷款';
  };
  
  const handleDeleteConfirm = () => {
    if (deletingPayment) {
      deletePayment(deletingPayment.id);
      setDeletingPayment(null);
    }
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-4">历史记录</h1>
      <div className="mb-4 border-b border-slate-200 dark:border-slate-700">
        <nav className="-mb-px flex space-x-6" aria-label="Tabs">
          <button
            onClick={() => setActiveTab('loans')}
            className={`${activeTab === 'loans' ? 'border-cyan-500 text-cyan-600 dark:text-cyan-400' : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300 hover:border-slate-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            已结清贷款
          </button>
          <button
            onClick={() => setActiveTab('payments')}
            className={`${activeTab === 'payments' ? 'border-cyan-500 text-cyan-600 dark:text-cyan-400' : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300 hover:border-slate-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            还款记录
          </button>
        </nav>
      </div>
      
      <div>
        {activeTab === 'loans' && (
          <div className="space-y-3">
            {paidOffLoans.length > 0 ? paidOffLoans.map(loan => (
              <div key={loan.id} className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-sm border border-slate-200 dark:border-slate-700">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-semibold text-slate-800 dark:text-slate-200">{loan.lender}</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">借款日期: {loan.loanDate}</p>
                  </div>
                  <div className="text-right">
                     <p className="text-green-600 dark:text-green-500 font-bold">已结清</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">¥{loan.amount.toLocaleString()}</p>
                  </div>
                </div>
              </div>
            )) : <EmptyState title="暂无记录" message="还没有已结清的贷款哦。" />}
          </div>
        )}
        
        {activeTab === 'payments' && (
           <div className="space-y-3">
            {payments.length > 0 ? [...payments].reverse().map(payment => (
              <div key={payment.id} className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-sm border border-slate-200 dark:border-slate-700 group">
                 <div className="flex justify-between items-center">
                   <div className="flex-1 min-w-0">
                     <p className="font-semibold text-slate-800 dark:text-slate-200 truncate">向 <span className="text-cyan-600 dark:text-cyan-400">{getLenderName(payment.loanId)}</span> 还款</p>
                     <p className="text-sm text-slate-500 dark:text-slate-400">{payment.date}</p>
                   </div>
                   <div className="flex items-center gap-4 ml-4">
                     <p className="font-bold text-xl text-slate-700 dark:text-slate-300">-¥{payment.amount.toLocaleString()}</p>
                     <button onClick={() => setDeletingPayment(payment)} className="p-2 rounded-full text-slate-400 hover:bg-red-100 hover:text-red-600 dark:hover:bg-red-900/40 dark:hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity">
                        <TrashIcon className="w-5 h-5" />
                     </button>
                   </div>
                 </div>
                 {payment.proofImageUrl && <a href={payment.proofImageUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-cyan-600 dark:text-cyan-400 hover:underline mt-2 inline-block">查看凭证</a>}
              </div>
            )) : <EmptyState title="暂无记录" message="您还没有任何还款记录。" />}
          </div>
        )}
      </div>

       {deletingPayment && (
        <ConfirmationModal
            isOpen={!!deletingPayment}
            onClose={() => setDeletingPayment(null)}
            onConfirm={handleDeleteConfirm}
            title="确认删除还款记录"
            message={`您确定要删除这笔 ${deletingPayment.amount.toLocaleString()} 元的还款记录吗？贷款的剩余金额将会相应增加，此操作无法撤销。`}
        />
      )}
    </div>
  );
};

export default HistoryPage;