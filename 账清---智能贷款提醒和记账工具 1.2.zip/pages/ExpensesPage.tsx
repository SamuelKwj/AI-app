import React, { useState, useMemo } from 'react';
import { Expense } from '../types';
import { PencilIcon } from '../components/icons/PencilIcon';
import { TrashIcon } from '../components/icons/TrashIcon';
import ConfirmationModal from '../components/ConfirmationModal';
import EmptyState from '../components/EmptyState';
import { formatCurrency } from '../utils/formatters';

interface ExpensesPageProps {
  expenses: Expense[];
  openEditModal: (expense: Expense) => void;
  deleteExpense: (expenseId: string) => void;
}

const CategoryChart: React.FC<{ data: { name: string; amount: number; percentage: number }[] }> = ({ data }) => {
  if (data.length === 0) {
    return null;
  }
  
  const colors = ['bg-sky-500', 'bg-emerald-500', 'bg-amber-500', 'bg-violet-500', 'bg-rose-500', 'bg-lime-500'];

  return (
    <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm mb-6 border border-slate-200 dark:border-slate-700">
      <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4">本月消费分类</h3>
      <div className="space-y-4">
        {data.map((item, index) => (
          <div key={item.name}>
            <div className="flex justify-between items-center text-sm mb-1.5">
              <div className="flex items-center gap-2">
                <span className={`w-3 h-3 rounded-full ${colors[index % colors.length]}`}></span>
                <span className="font-semibold text-slate-700 dark:text-slate-300">{item.name}</span>
              </div>
              <span className="font-medium text-slate-500 dark:text-slate-400">{formatCurrency(item.amount)}</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5">
              <div
                className={`${colors[index % colors.length]} h-2.5 rounded-full transition-all duration-500 ease-out`}
                style={{ width: `${item.percentage}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const MonthlyExpenseChart: React.FC<{ expenses: Expense[] }> = ({ expenses }) => {
  const { labels, values, rawValues, maxAmount } = useMemo(() => {
    const data: { [key: string]: number } = {};
    const now = new Date();
    
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      data[monthKey] = 0;
    }

    expenses.forEach(expense => {
      if (expense.date) {
        const monthKey = expense.date.substring(0, 7);
        if (data[monthKey] !== undefined) {
          data[monthKey] += expense.amount;
        }
      }
    });

    const maxValue = Math.max(...Object.values(data));
    // Calculate a "nice" top value for the chart's Y-axis
    const topValue = maxValue > 0 ? Math.ceil(maxValue / 1000) * 1000 : 1000;

    return {
      labels: Object.keys(data).map(k => `${parseInt(k.split('-')[1])}月`),
      values: Object.values(data).map(v => topValue > 0 ? (v / topValue) * 100 : 0),
      rawValues: Object.values(data),
      maxAmount: topValue
    };
  }, [expenses]);

  const hasData = rawValues.some(v => v > 0);

  return (
    <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
      <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4">月度支出趋势</h3>
       {hasData ? (
        <div className="relative h-56 pr-4 pl-12">
            <div className="absolute top-0 left-0 h-full flex flex-col justify-between -translate-y-2 text-xs text-slate-400 text-right w-10">
                <span>{formatCurrency(maxAmount).replace(/\.00$/, '')}</span>
                <span>{formatCurrency(maxAmount / 2).replace(/\.00$/, '')}</span>
                <span>¥0</span>
            </div>
            <div className="absolute top-0 left-12 w-[calc(100%-3rem)] h-full">
                <div className="w-full h-full border-l border-slate-200 dark:border-slate-700"></div>
            </div>
            <div className="absolute top-0 left-12 w-[calc(100%-3rem)] h-full flex flex-col justify-between">
                <div className="w-full border-t border-slate-200 dark:border-slate-700 border-dashed"></div>
                <div className="w-full border-t border-slate-200 dark:border-slate-700 border-dashed"></div>
                <div className="w-full border-t border-slate-300 dark:border-slate-600"></div>
            </div>

            <div className="relative flex justify-between items-end h-full space-x-3 z-10 ml-1">
                {labels.map((label, index) => (
                <div key={label} className="flex-1 flex flex-col items-center justify-end group h-full">
                    <div className="relative -top-2">
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 bg-slate-700 dark:bg-slate-200 text-white dark:text-black rounded-md px-2 py-1 text-xs shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-20">
                            {formatCurrency(rawValues[index])}
                        </div>
                    </div>
                    <div 
                        className="w-full bg-gradient-to-t from-cyan-500 to-sky-400 rounded-t-lg transition-all duration-300 ease-in-out group-hover:from-cyan-400 group-hover:to-sky-300" 
                        style={{ height: values[index] > 0 ? `${values[index]}%` : '2px' }}
                    ></div>
                    <div className="text-sm text-slate-600 dark:text-slate-300 mt-2">{label}</div>
                </div>
                ))}
            </div>
        </div>
       ) : (
        <div className="text-center py-16">
            <p className="text-slate-500 dark:text-slate-400">暂无历史支出数据来生成图表。</p>
        </div>
       )}
    </div>
  );
};

const ExpensesPage: React.FC<ExpensesPageProps> = ({ expenses, openEditModal, deleteExpense }) => {
  const [deletingExpense, setDeletingExpense] = useState<Expense | null>(null);

  const groupedExpenses = useMemo(() => {
    return expenses.reduce((acc, expense) => {
      const date = expense.date;
      if (!acc[date]) {
        acc[date] = [];
      }
      acc[date].push(expense);
      return acc;
    }, {} as Record<string, Expense[]>);
  }, [expenses]);
  
  const sortedDates = Object.keys(groupedExpenses).sort((a,b) => new Date(b).getTime() - new Date(a).getTime());

  const { totalThisMonth, categoryData } = useMemo(() => {
      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
      
      const monthlyExpenses = expenses.filter(e => e.date >= firstDayOfMonth);
      
      const total = monthlyExpenses.reduce((sum: number, e) => sum + e.amount, 0);

      const data = monthlyExpenses.reduce((acc: Record<string, number>, expense) => {
        acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
        return acc;
      }, {});
      
      const chartData = Object.entries(data)
        .map(([name, amount]) => ({ name, amount, percentage: total > 0 ? (amount / total) * 100 : 0 }))
        .sort((a, b) => b.amount - a.amount);

      return { totalThisMonth: total, categoryData: chartData };
  }, [expenses]);
  
  const handleDeleteConfirm = () => {
      if (deletingExpense) {
          deleteExpense(deletingExpense.id);
          setDeletingExpense(null);
      }
  };

  return (
    <div className="p-4">
      <div className="mb-4">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">消费记录</h1>
      </div>

      <div className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm mb-6 border border-slate-200 dark:border-slate-700">
        <p className="text-sm text-slate-500 dark:text-slate-400">本月支出</p>
        <p className="text-2xl font-bold text-slate-800 dark:text-slate-200 mt-1">{formatCurrency(totalThisMonth)}</p>
      </div>
      
      <CategoryChart data={categoryData} />

      <div className="mb-6">
        <MonthlyExpenseChart expenses={expenses} />
      </div>

      {expenses.length > 0 ? (
        <div className="space-y-6">
          <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 -mb-2">消费明细</h3>
          {sortedDates.map(date => (
            <div key={date}>
              <h2 className="font-semibold text-slate-600 dark:text-slate-400 pb-2 mb-2 border-b dark:border-slate-700">{new Date(date).toLocaleDateString('zh-CN', { month: 'long', day: 'numeric' })}</h2>
              <ul className="space-y-2">
                {groupedExpenses[date].map(expense => (
                  <li key={expense.id} className="flex justify-between items-center bg-white dark:bg-slate-800 p-3 rounded-md group border border-transparent hover:border-slate-200 dark:hover:border-slate-700 transition-colors">
                    <div>
                      <p className="font-medium text-slate-800 dark:text-slate-200">{expense.description}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{expense.category}</p>
                    </div>
                    <div className="flex items-center">
                        <p className="font-semibold text-red-500 dark:text-red-400">{formatCurrency(expense.amount)}</p>
                        <div className="ml-2 flex opacity-0 group-hover:opacity-100 transition-opacity">
                            <button onClick={() => openEditModal(expense)} className="p-2 text-slate-500 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400">
                                <PencilIcon className="w-4 h-4"/>
                            </button>
                             <button onClick={() => setDeletingExpense(expense)} className="p-2 text-slate-500 dark:text-slate-400 hover:text-red-600 dark:hover:text-red-400">
                                <TrashIcon className="w-4 h-4"/>
                            </button>
                        </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      ) : (
         <EmptyState title="暂无记录" message="点击下方的 “+” 开始记录你的第一笔消费吧！" />
      )}


      {deletingExpense && <ConfirmationModal isOpen={!!deletingExpense} onClose={() => setDeletingExpense(null)} onConfirm={handleDeleteConfirm} title="确认删除消费记录" message={`您确定要删除 “${deletingExpense.description}” 这笔消费记录吗？`} />}
    </div>
  );
};

export default ExpensesPage;