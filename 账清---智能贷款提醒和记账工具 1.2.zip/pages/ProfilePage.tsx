import React, { useRef, useState } from 'react';
import { Loan, Payment, Expense } from '../types';
import { MoonIcon } from '../components/icons/MoonIcon';
import { SunIcon } from '../components/icons/SunIcon';
import { DownloadIcon } from '../components/icons/DownloadIcon';
import { UploadIcon } from '../components/icons/UploadIcon';
import { XCircleIcon } from '../components/icons/XCircleIcon';

interface ProfilePageProps {
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
  loans: Loan[];
  payments: Payment[];
  expenses: Expense[];
  setLoans: React.Dispatch<React.SetStateAction<Loan[]>>;
  setPayments: React.Dispatch<React.SetStateAction<Payment[]>>;
  setExpenses: React.Dispatch<React.SetStateAction<Expense[]>>;
  showToast: (message: string, type?: 'success' | 'error') => void;
  expenseCategories: string[];
  setExpenseCategories: React.Dispatch<React.SetStateAction<string[]>>;
}


const ProfilePage: React.FC<ProfilePageProps> = ({ theme, setTheme, loans, payments, expenses, setLoans, setPayments, setExpenses, showToast, expenseCategories, setExpenseCategories }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [newCategory, setNewCategory] = useState('');

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  const handleExport = () => {
    try {
      const dataToExport = {
        loans,
        payments,
        expenses,
        expenseCategories,
        exportedAt: new Date().toISOString(),
      };
      const dataStr = JSON.stringify(dataToExport, null, 2);
      const blob = new Blob([dataStr], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const date = new Date().toISOString().slice(0, 10);
      a.download = `zhangqing-backup-${date}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showToast('数据导出成功！');
    } catch (error) {
      console.error("Failed to export data:", error);
      showToast('数据导出失败', 'error');
    }
  };
  
  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result;
        if (typeof text !== 'string') throw new Error("File is not valid text.");
        const data = JSON.parse(text);

        if (Array.isArray(data.loans) && Array.isArray(data.payments) && Array.isArray(data.expenses)) {
          if (window.confirm("导入新数据将会覆盖当前所有数据，您确定要继续吗？此操作不可撤销。")) {
            setLoans(data.loans);
            setPayments(data.payments);
            setExpenses(data.expenses);
            if(Array.isArray(data.expenseCategories)) {
              setExpenseCategories(data.expenseCategories);
            }
            showToast('数据导入成功！');
          }
        } else {
          throw new Error("备份文件格式不正确。");
        }
      } catch (error: any) {
        console.error("Failed to import data:", error);
        showToast(`数据导入失败: ${error.message}`, 'error');
      } finally {
        if (fileInputRef.current) {
          fileInputRef.current.value = "";
        }
      }
    };
    reader.readAsText(file);
  };
  
  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedCategory = newCategory.trim();
    if (trimmedCategory && !expenseCategories.includes(trimmedCategory)) {
      setExpenseCategories(prev => [...prev, trimmedCategory]);
      setNewCategory('');
      showToast('分类添加成功');
    } else if (expenseCategories.includes(trimmedCategory)) {
      showToast('分类已存在', 'error');
    }
  };

  const handleDeleteCategory = (categoryToDelete: string) => {
    if (expenses.some(e => e.category === categoryToDelete)) {
        if (!window.confirm(`“${categoryToDelete}” 分类下已有消费记录，删除后这些记录的分类将变为“其他”。确定要删除吗？`)) {
            return;
        }
        setExpenses(prev => prev.map(e => e.category === categoryToDelete ? { ...e, category: '其他' } : e));
    }
    setExpenseCategories(prev => prev.filter(c => c !== categoryToDelete));
    showToast('分类已删除');
  };


  return (
    <div className="p-4 flex flex-col h-full">
       <div className="flex-grow flex flex-col items-center justify-center text-center">
          <div className="w-24 h-24 rounded-full bg-cyan-100 dark:bg-cyan-900/50 flex items-center justify-center mb-4">
            <span className="text-4xl text-cyan-600 dark:text-cyan-400 font-bold">账</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">账清</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-2">v1.2.0</p>
          <p className="mt-6 text-slate-600 dark:text-slate-300 max-w-sm">
            一个简洁的贷款与消费记录应用，帮助您更好地管理个人财务。
          </p>
      </div>

      <div className="space-y-4 pb-4">
        <div className="bg-white dark:bg-slate-800 p-4 rounded-lg flex justify-between items-center shadow-sm">
          <span className="font-medium">外观模式</span>
          <button onClick={toggleTheme} className="p-2 rounded-full bg-slate-100 dark:bg-slate-700">
            {theme === 'light' ? <MoonIcon className="w-5 h-5 text-slate-600" /> : <SunIcon className="w-5 h-5 text-yellow-400" />}
          </button>
        </div>
        
        <div className="bg-white dark:bg-slate-800 p-4 rounded-lg space-y-3 shadow-sm">
            <h3 className="font-medium">消费分类管理</h3>
            <div className="flex flex-wrap gap-2">
                {expenseCategories.map(cat => (
                <div key={cat} className="bg-slate-100 dark:bg-slate-700 rounded-full pl-3 pr-1 py-1 text-sm flex items-center gap-1">
                    {cat}
                    {cat !== '其他' && (
                        <button onClick={() => handleDeleteCategory(cat)} className="text-slate-400 hover:text-red-500 rounded-full">
                            <XCircleIcon className="w-5 h-5" />
                        </button>
                    )}
                </div>
                ))}
            </div>
             <form onSubmit={handleAddCategory} className="flex gap-2 pt-2">
                <input 
                type="text" 
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                placeholder="输入新分类名称"
                className="flex-grow min-w-0 px-3 py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md shadow-sm text-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500"
                />
                <button type="submit" className="px-4 py-2 bg-cyan-500 text-white text-sm font-semibold rounded-md hover:bg-cyan-600">添加</button>
            </form>
        </div>


        <div className="bg-white dark:bg-slate-800 p-4 rounded-lg space-y-3 shadow-sm">
            <h3 className="font-medium">数据管理</h3>
            <div className="flex gap-3">
                <button onClick={handleExport} className="w-full flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-medium rounded-md hover:bg-slate-200 dark:hover:bg-slate-600">
                    <DownloadIcon className="w-5 h-5" /> 导出数据
                </button>
                 <button onClick={handleImportClick} className="w-full flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-medium rounded-md hover:bg-slate-200 dark:hover:bg-slate-600">
                    <UploadIcon className="w-5 h-5" /> 导入数据
                </button>
                <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept=".json" />
            </div>
        </div>
      </div>
      
       <div className="text-center text-sm text-slate-400 dark:text-slate-500 py-4">
          <p>由 AI 强力驱动</p>
          <p>祝您生活愉快，账目清晰！</p>
        </div>
    </div>
  );
};

export default ProfilePage;