
export interface Loan {
  id: string;
  lender: string;
  amount: number;
  remainingAmount: number;
  interestRate: number;
  loanDate: string;
  repaymentDay: number; // Day of the month, e.g., 15
  termInMonths?: number;
}

export interface Payment {
  id: string;
  loanId: string;
  amount: number;
  date: string;
  proofImageUrl?: string; // Base64 encoded image
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  category: string;
  date: string;
}